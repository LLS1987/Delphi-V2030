# Unsupported folder contents

This folder contains:
- Old and to a large extent obsolete documentation (Old docs).
-  VCL components providing python wrappers for TDataset,  TBDEDataset, TTable and TQuery.
(VCL folder).  Deprecated and unsupported.  They are superseded by WrapDelphi and WrapFireDAC.