## Tutorials

This folder contains text and video tutorials accompanied with slides and demo source code.

- [Getting Started with Python4Delphi](https://youtu.be/hjY6lBgrHhM)
- [Overview Video](https://youtu.be/jLuxTfct3CU)
- [Webinar I](https://github.com/pyscripter/python4delphi/tree/master/Tutorials/Webinar%20I)
- [Webinar II](https://github.com/pyscripter/python4delphi/tree/master/Tutorials/Webinar%20II)
- [Introductory tutorial](https://github.com/pyscripter/python4delphi/wiki/Files/Chapter80Tutorial.pdf) by Dr K. R. Bond.
- [Another tutorial](http://www.softwareschule.ch/download/maxbox_starter86.pdf) by Max Kleiner