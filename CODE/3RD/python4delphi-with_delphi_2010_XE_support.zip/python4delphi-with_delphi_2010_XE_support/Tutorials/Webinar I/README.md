
# Webinar: – Python for Delphi Developers – Part I

![P4D Logo](https://github.com/pyscripter/python4delphi/wiki/Images/Python4Delphi-Libraries.png)

- [Webinar Info](https://blogs.embarcadero.com/?p=55050)

- [Video replay](https://youtu.be/aCz5h96ObUM)

- [Slides](https://www.slideshare.net/embarcaderotechnet/python-for-delphi-developers-part-1-introduction)

- Source code included in this folder