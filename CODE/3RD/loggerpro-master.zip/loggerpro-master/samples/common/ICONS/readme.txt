These icons are from Icojam (http://www.icojam.com)

Blueberry Basic [bitmap]

Ammount of icons:
111

Icon Sizes:
32x32

File Types:
.png: 
32x32(32bit)
.ico: 
32x32(xp,8bit)
.gif 
32x32 (indexed)
.icns: 
32x32(rgb/a,8bit,mono)